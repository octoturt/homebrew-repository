#!/bin/bash

ln -s $HOMEBREW_PREFIX/bin/python3 ./python